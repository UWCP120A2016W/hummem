package cp120a.hummem.hw6;

import java.util.ArrayList;

import cp120a.hummem.hw6.Point;

public class Circle extends Shape {

public static void main(String[] args) throws MyIllegalArgumentException {
		
	// Create new ArrayList for input.
	
		ArrayList<Double> coords = new ArrayList<>(); // Array to hold input
		
		double radius = 0.0;
		String instruction = "Enter the radius center coordinates";
		
		getCoords(coords, instruction, "Enter x coordinate: ", "Enter y coordinate: "); 
		
		// System.out.println("xCoord.get(0) = " + coords.get(0) + " yCoord.get(1) = " + coords.get(1));
		Point p1 = new Point(coords.get(0), coords.get(1)); // Create a new point

		// Get the circle radius	
			
		radius = getLen("Enter the radius of the circle: ");
		
		// System.out.println("p1.xCoord = " + p1.xCoord + " p1.yCoord = " + p1.yCoord);
		System.out.println(" The radius = " + radius);
		
		// Build a Circle
		try {
		
			Circle Circle = new Circle(p1, radius);
			
			// Get the statistics
			
			System.out.println("\n\nThe area of the Circle is: " + Circle.getArea());
			System.out.println("The perimeter of the Circle is: " + Circle.getPerimeter());
			System.out.println("The perimeter of the bounding rectangle is: " + Circle.getMinimumBoundingRectangle());	
		
		} catch (IllegalArgumentException e) {
		    throw new MyIllegalArgumentException("Exception thrown by Circle Constructor");
		}
		
		
	}// End of PSVM

	private double theArea = 0.0;
	private double thePerimeter = 0.0;
	private double theBoundary = 0.0;
	private double theRadius = 0.0;
	private Point aPoint = new Point(0.0,0.0);
	private double xCoord;
	private double yCoord;
	
	//Default Constructor
	
	public Circle(){
	};
	
	// Constructor for a Circle

	public Circle(Point p1, double len) throws IllegalArgumentException{
	
		 aPoint.setxCoord(p1.getxCoord());
		 aPoint.setyCoord(p1.getyCoord());
		 theRadius = len;
		 
		 System.out.println(" aPoint.xCoord = " + aPoint.getxCoord());
		 
	}	 // End of Constructor	

// Getters

	@Override
	public double getArea() {
		
		theArea = Math.pow(this.theRadius,2) * Math.PI;
		theArea = Math.round(theArea * 100);
		theArea = theArea/100;
		
		return theArea;
	}

	@Override
	public double getPerimeter() {
		
		thePerimeter = 2 * Math.PI * this.theRadius;;
		thePerimeter = Math.round(thePerimeter * 100);
		thePerimeter = thePerimeter/100;
		
		return thePerimeter;
	}

	@Override
	public double getMinimumBoundingRectangle() {
		
		theBoundary = 2 * this.theRadius * 4;
		theBoundary = Math.round(theBoundary * 100);
		theBoundary = theBoundary/100;
		
		return theBoundary;
	}

	@Override
	public void move(double deltaX, double deltaY) {
		
		double x = 0.0;
		double y = 0.0;
		String name = getName();
		
		// The center of the circle is moved by changing the center coordinates
		
		x = this.xCoord += getxCoord() + deltaX;
		y = this.yCoord += getyCoord() + deltaY;
		
		Point newCenter = new Point(x,y);
		
		Square newcircle = new Square(newCenter, theRadius);	
		newcircle.setName(name);
	}

	public double getxCoord() {
		return this.xCoord;
	}
	

	public double getyCoord() {
		return this.yCoord;
	}
	
	public void setxCoord(double x) {
		// TODO Auto-generated method stub
		
	}

	public void setyCoord(double y) {
		// TODO Auto-generated method stub
		
	}
}
