package cp120a.hummem.hw6;

import java.util.ArrayList;

public class Rectangle extends Shape {

private static String instruction;

public static void main(String[] args) throws MyIllegalArgumentException {
		
	// Create new ArrayList for input.
	
			ArrayList<Double> coords = new ArrayList<>(); // Array to hold input

			double xMin = 0.0; 
			double yMin = 0.0;
			double xMax = 0.0; 
			double yMax = 0.0;
			
			String[] instructions = {"Enter the diagonal start coordinates", "Enter the diagonal end coordinates"};
			String instruction = null;
			
			for(int i = 0; i <= 1; i++){ // calculating 2 sides from the diagonal
				
				instruction = instructions[i];
				
				getCoords(coords, instruction, "Enter x coordinate: ", "Enter y coordinate: "); 
				
			}
			
			// Set constructor parameters
			
			xMin = coords.get(0); // x coordinate from input
			yMin = coords.get(1); // y coordinate from input
			xMax = coords.get(2); // x coordinate from input
			yMax = coords.get(3); // y coordinate from input
	
			try {
		
		Rectangle Rectangle = new Rectangle(xMin, yMin, xMax, yMax);
		
		// Get the statistics
		
		System.out.println("\n\nThe area of the Rectangle is: " + Rectangle.getArea());
		System.out.println("The perimeter of the Rectangle is: " + Rectangle.getPerimeter());
		System.out.println("The perimeter of the bounding rectangle is: " + Rectangle.getMinimumBoundingRectangle());
		
			} catch (IllegalArgumentException e) {
			    throw new MyIllegalArgumentException("Exception thrown by Rectangle Constructor");
			}
			
		}// End of PSVM


	private double theArea = 0.0;
	private double thePerimeter = 0.0;
	private double theBoundary = 0.0;
	private double base = 0.0; // base of rectangle
	private double height = 0.0; // height of rectangle
	private final static int sides = 4; // Number of sides in the shape
	
	private double axMin = 0.0;
	private double ayMin = 0.0;		
	private double axMax = 0.0;
	private double ayMax = 0.0;	
	
	//Default Constructor
	
	public Rectangle(){
	};
	
	// Constructor for a Rectangle

	public Rectangle(double xMin, double yMin, double xMax, double yMax)throws IllegalArgumentException {
	
			// Set coordinates for Move 
		
			axMin = xMin;
			ayMin = yMin;
			axMax = xMax;
			ayMax = yMax;
			
		 	Point p1 = new Point(axMin, ayMin);
		 	Point p2 = new Point(axMax, ayMin);
		 	
		 	try {
			base = calcSegLen(p1, p2);
			
			Point p3 = new Point(axMax, ayMax);
			
			height = calcSegLen(p2, p3);
			
		 	} catch (IllegalArgumentException e) {
			    throw new MyIllegalArgumentException("Exception thrown by Rectangle.calcSegLen");
			}
		

		/* System.out.println("Area = " + area);
		System.out.println("Perimeter = " + perimeter);
		System.out.println("Boundary = " + boundary); */
		
	}	 // End of Constructor	

// Getters

	@Override
	public double getArea() {
		theArea = this.base * this.height;
		return theArea;
	}

	@Override
	public double getPerimeter() {
		thePerimeter =  2 * (this.base + this.height);
		return thePerimeter;
	}

	@Override
	public double getMinimumBoundingRectangle() {
		theBoundary =  2 * (this.base + this.height);
		return theBoundary;
	}

	@Override
	public void move(double xDelta, double yDelta) throws IllegalArgumentException{
		
		String name = getName();
		
		axMin += axMin + xDelta;
		ayMin += ayMin + yDelta;
		axMax += axMax + xDelta;
		ayMax += ayMax + yDelta;
		
		Rectangle newRectangle = new Rectangle(axMin, ayMin, axMax, ayMax);
		newRectangle.setName(name);
	}
	
}
