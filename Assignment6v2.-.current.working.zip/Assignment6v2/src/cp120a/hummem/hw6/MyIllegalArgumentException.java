package cp120a.hummem.hw6;

public class MyIllegalArgumentException extends IllegalArgumentException {

		static int excepCount = 0;
	
	public MyIllegalArgumentException(String s) {
		super(s);
		
		excepCount++;
	}
	
	public static int getExceptionCount(){
		return excepCount;
	}
}
