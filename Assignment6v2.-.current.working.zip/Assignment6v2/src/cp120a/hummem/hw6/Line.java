package cp120a.hummem.hw6;

import java.util.ArrayList;

public class Line extends Shape {
	
public static void main(String[] args) throws MyIllegalArgumentException {
		
		// Create new ArrayList for input.
		
		ArrayList<Double> coords = new ArrayList<>(); // Array List to hold input
		
		double x = 0.0; // x of the current coordinate
		int arrSize = 0;
		
		String instruction = "Enter line segment coordinates";
		
		while(true){
			
			getCoords(coords, instruction, "Enter X coordinate (or 999 to quit: ", "Enter Y coordinate: "); 
			
			arrSize = coords.size();
			x = coords.get(arrSize-1);
			
			if(x == 999.0) // break condition
	        	break;
		}
		
		x = coords.get(arrSize-1);
		arrSize = coords.size();
		
		System.out.println("Im out of the loop " + "arrSize  = " + (arrSize) + " x = " + x);
		
		coords.remove(arrSize - 1); // Remove exit condition value
		
		
		try {
		
			Line Line = new Line(coords);
			
		// Get the statistics
		
		System.out.println("\n\nThe area of the Rectangle is: " + Line.getArea());
		System.out.println("The perimeter of the Rectangle is: " + Line.getPerimeter());
		System.out.println("The perimeter of the bounding rectangle is: " + Line.getMinimumBoundingRectangle());
		
		} catch (IllegalArgumentException e) {
		    throw new MyIllegalArgumentException("Exception thrown by Rectangle Constructor");
		}
		
		
		
	} // End of PSVM


	private double area = 0.0;
	private double perimeter = 0.0;
	private double boundary = 0.0;
	private double lineLength = 0.0;
	
	//Default Constructor
	
	public Line(){
	};
	
	// Constructor for a Line

	public Line(ArrayList<Double> coords){

		 double x = 0.0; // x coordinate
		 double y = 0.0; // y coordinate
		 double line = 0.0; // line length
		 int pointCount = 0; // Point Creation Counter
		 Point[] pointArr = new Point[coords.size()/2]; // Array containing points
		 System.out.println(" pointArr size = " + pointArr.length);
		 Point p1 = new Point(x,y); // start point of a line
		 Point p2 = new Point(x,y); // end point of a line
		 
		 // Fields to compute bounding rectangle
		 
		 double inf = Double.POSITIVE_INFINITY;
		 double nInf = Double.NEGATIVE_INFINITY;
		 Point pmax = new Point(x,y); //max xy of bounding rectangle (if exists)
		 Point pmin = new Point(x,y); //min xy of bounding rectangle (if exists)
		 double maxX = nInf;
		 double maxY = nInf;
		 double minX = inf;
		 double minY = inf;
		 double base = 0.0; // base of bounding rectangle
		 double height = 0.0; // height of bounding rectangle
		 
		// if y coordinates of the line segments are not the same, or x coordinate are not the 
		// same, then bounding rectangle exists (line is a zig zag) 
		 
		 // Populate an array of points from the entered coordinates
		 
		for(int i = 0; i <= coords.size() - 1; i+=2) {
					 
			x = coords.get(i); // x coordinate from input
			y = coords.get(i+1); // y coordinate from input
			pointArr[pointCount] = new Point(x,y);
			pointCount++; //tracks number of points input
		}	
		
		/* Compute length of line segment */
	
		for(int i = 0; i <= pointCount-2; i++){ // -1 for index, and -1 for # of segments (# points - 1) 
			
			p1 = pointArr[i];
			p2 = pointArr[i+1];

			lineLength += calcSegLen(p1, p2);
			
		}
		
		// Determine min and max points from the set of points entered 
		// to calculate diagonal of bounding rectangle
		
		for(int i = 0; i <= pointCount-1; i++)
		{
			minX = Math.min(pointArr[i].getxCoord(), minX);
			minY = Math.min(pointArr[i].getyCoord(), minY);
			maxX = Math.max(pointArr[i].getxCoord(), maxX);
			maxY = Math.min(pointArr[i].getyCoord(), maxY);
		}

		// If the line is a straight line, no bounding rectangle
		
		if(minX == maxX && minY == maxY) { // This is a straight line, you're done
				boundary = Double.NaN;
		} else {	
				// Calculate Base and Height of Bounding Rectangle
			
				Point b1 = new Point(minX, minY);
				Point b2 = new Point(maxX, minY);
				base = calcSegLen(b1, b2);
				Point h1 = new Point(maxX, minY);
				Point h2 = new Point(maxX, maxY);
				height = calcSegLen(b1, b2);
				boundary = 2 * base * height;
				
		}
	
} // End of Constructor	

	
// Getters

	@Override
	public double getArea() {
		return Double.NaN;	 // A line has no area
	}

	@Override
	public double getPerimeter() {
		return 2 * (this.lineLength);
	}

	@Override
	public double getMinimumBoundingRectangle() {
		return this.boundary;
	}

	@Override
	public void move(double x, double y) {
		// TODO Auto-generated method stub
		
	}	
	
}
