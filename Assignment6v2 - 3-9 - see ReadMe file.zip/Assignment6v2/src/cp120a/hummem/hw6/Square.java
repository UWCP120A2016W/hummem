package cp120a.hummem.hw6;

import java.util.ArrayList;

public class Square extends Rectangle {

public static void main(String[] args) throws MyIllegalArgumentException {
		
		// Create new ArrayList for input.
		
		final int sides = 4;
		ArrayList<Double> coords = new ArrayList<>(); // Array to hold input
		double radius = 0.0;
		String[] instructions = {"Enter the diagonal start coordinates", "Enter the diagonal end coordinates"};
		String instruction = null;
			
			instruction = instructions[0];
			
			getCoords(coords, instruction, "Enter x coordinate: ", "Enter y coordinate: "); 
			
			Point center = new Point(coords.get(0), coords.get(1)); // Create a new point
			
			instruction = instructions[1];
			
			radius = getLen("Enter the radius of the Square");
	
		// Build a Square
		
			try {

			Square square = new Square(center, radius);		
			
			// Get the statistics
			
			System.out.println("\n\nThe area of the Square is: " + square.getArea());
			System.out.println("The perimeter of the Square is: " + square.getPerimeter());
			System.out.println("The perimeter of the bounding Square is: " + square.getMinimumBoundingRectangle());
			
			} catch (IllegalArgumentException e) {
			    throw new MyIllegalArgumentException("Exception thrown by Square Constructor");
			}
		
	} // End of PSVM
	
	
	private double sideLen = 0.0;
	private double xCoord;
	private double yCoord;
	private double theRadius = 0.0;
	private double theArea = 0.0;
	private double thePerimeter = 0.0;
	private double theBoundary;
	private Point  theCenter = new Point(0.0,0.0); // Center of the square

	public Square(Point center, double radius) throws IllegalArgumentException{
		
		// Set the center of the square
		
		theCenter = center;
		theRadius = radius;
		
	} //End of Constructor
	
	@Override
	public double getArea() {
		theArea = Math.pow((theRadius * 2),2);
		return theArea;
	}
	
	@Override
	public double getPerimeter() {
		thePerimeter =  4 * 2 * theRadius;
		return thePerimeter;
	}
	
	@Override
	public double getMinimumBoundingRectangle() {
		theBoundary =  4 * 2 * theRadius;
		return theBoundary;
	} 
	
	@Override
	public void move(double deltaX, double deltaY) {
		
		double x = 0.0;
		double y = 0.0;
		String name = getName();
		
		// The center of the square is moved by changing the center coordinates
		
		x = this.xCoord += getxCoord() + deltaX;
		y = this.yCoord += getyCoord() + deltaY;
		
		try {
			
		Point newCenter = new Point(x,y);
		
		Square newsquare = new Square(newCenter, theRadius);	
		newsquare.setName(name);
		
		} catch (IllegalArgumentException e) {
		  throw new MyIllegalArgumentException("Exception thrown by Square constructor");
		}
		
	}
	
	public double getxCoord() {
		return this.xCoord;
	}

	public double getyCoord() {
		return this.yCoord;
	}
	
}


