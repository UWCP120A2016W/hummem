package cp120a.hummem.hw6;

public interface Movable {
	
	  public void move(double deltaX, double deltaY);
	  
}
