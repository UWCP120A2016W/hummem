package cp120a.hummem.hw6;

public interface Named {
	
	public String getName();
	public void setName(String x);
	
}
