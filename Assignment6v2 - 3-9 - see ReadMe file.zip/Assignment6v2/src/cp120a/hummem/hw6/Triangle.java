package cp120a.hummem.hw6;

import java.util.ArrayList;

public class Triangle extends Shape {

public static void main(String[] args) throws MyIllegalArgumentException {
		
		// Create new ArrayList for input.
		
		ArrayList<Double> XY = new ArrayList<>(); // Array to hold input
		Point[] pointArr = new Point[sides]; // Array containing a points

		double x = 0.0; // x of the current coordinate
		double y = 0.0; // y of the current coordinate
		
		String[] instructions = {"Enter triangle base start point", "Enter triangle base end point",
				"Enter the triangle height end point"};
		String instruction = null;
		
		for(int i = 0; i <= pointArr.length - 1; i++){
			
			instruction = instructions[0];
			
			getCoords(XY, instruction, "Enter x coordinate: ", "Enter y coordinate: "); 
			
			x = XY.get(0); // x coordinate from input
			y = XY.get(1); // y coordinate from input
			
			System.out.println("x = " + x + " y " + y);
			
			pointArr[i] = new Point(x, y); // Create a new point
	
			XY.clear();
		}
		
		// Assign the 3 point coordinates
		
		Point p1 = pointArr[0];
		Point p2 = pointArr[1];
		Point p3 = pointArr[2];
		
		System.out.println(" Point 1 x " + p1.getxCoord() + " Point 1 y " + p1.getyCoord());	
		
		
		// Build a triangle
		
		Triangle triangle = new Triangle(p1, p2, p3);
		
		// Get the statistics
		
		System.out.println("\n\nThe area of the triangle is: " + triangle.getArea());
		System.out.println("The perimeter of the triangle is: " + triangle.getPerimeter());
		System.out.println("The perimeter of the bounding rectangle is: " + triangle.getMinimumBoundingRectangle());

	}// End of PSVM


private double area = 0.0;
private double perimeter = 0.0;
private double boundary = 0.0;
private double side1 = 0.0;
private double side2 = 0.0;
private double side3 = 0.0;
private double xCoord;
private double yCoord;
private Point point1 = new Point(0.0,0.0);
private Point point2 = new Point(0.0,0.0);
private Point point3 = new Point(0.0,0.0);

static int sides = 3; // Number of sides in the shape

	// Constructor for a Triangle

	

public Triangle(Point p1, Point p2, Point p3){
	
	//System.out.println(" Point 1 x " + p1.getxCoord() + " Point 1 y " + p1.getyCoord());
	
		side1 = calcSegLen(p1, p2);
		side2 = calcSegLen(p2, p3);
		side3 = calcSegLen(p1, p3);
		
	// coordinates for the move
		
		point1 = p1;
		point2 = p2;
		point3 = p3;
		
	}	 // End of Constructor	
	
	@Override
	public double getArea() {
		return .50 * (side1 * side2);
	}

	@Override
	public double getPerimeter() {
		return side1 + side2 + side3;
	}

	@Override
	public double getMinimumBoundingRectangle() {
		return  2 * (side1 + side2);
	}

	@Override
	public void move(double deltaX, double deltaY) {
		
		// Set the updated points
		
		point1.setxCoord(point1.getxCoord() + deltaX);
		point1.setyCoord(point1.getyCoord() + deltaY);
		point2.setxCoord(point2.getxCoord() + deltaX);
		point2.setyCoord(point2.getyCoord() + deltaY);
		point3.setxCoord(point3.getxCoord() + deltaX);
		point3.setyCoord(point3.getyCoord() + deltaY);
		
		// Set new sides based on the updated coordinates (move the triangle)
		
		side1 = calcSegLen(point1, point2);
		side2 = calcSegLen(point2, point3);
		side3 = calcSegLen(point1, point3);
		
		
	}

	public double getxCoord() {
		return this.xCoord;
	}
	
	public double getyCoord() {
		return this.yCoord;
	}

	public void setxCoord(double x) {
		this.xCoord = x;
	}

	public void setyCoord(double y) {
		this.yCoord = y;
	}
	
}
