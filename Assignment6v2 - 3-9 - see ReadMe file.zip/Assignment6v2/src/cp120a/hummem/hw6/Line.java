package cp120a.hummem.hw6;

import java.util.ArrayList;

public class Line extends Shape {
	
public static void main(String[] args) throws MyIllegalArgumentException {
		
		// Create new ArrayList for input.
		
		ArrayList<Double> coords = new ArrayList<>(); // Array List to hold input
		ArrayList<Point> points = new ArrayList<>(); // Array List to hold input
		
		
		double x = 0.0; // x of the current coordinate
		int arrSize = 0;
		
		String instruction = "Enter line segment coordinates";
		
		while(true){
			
			getCoords(coords, instruction, "Enter X coordinate (or 999 to quit: ", "Enter Y coordinate: "); 
			
			arrSize = coords.size();
			x = coords.get(arrSize-1);
			
			if(x == 999.0) // break condition
	        	break;
		}
		
		x = coords.get(arrSize-1);
		arrSize = coords.size();
			
		coords.remove(arrSize - 1); // Remove exit condition value
		
		// turn coordinates into points
		
		for(int i = 0; i <= coords.size() - 1; i+=2) {
			
			Point newPoint = new Point(coords.get(i),coords.get(i+1));
			points.add(newPoint);
			
		}	
		
		try {
		
			Line Line = new Line(points);
			
		// Get the statistics
		
		System.out.println("\n\nThe area of the Line is: " + Line.getArea());
		System.out.println("The perimeter of the Line is: " + Line.getPerimeter());
		System.out.println("The perimeter of the bounding rectangle is: " + Line.getMinimumBoundingRectangle());
		
		} catch (IllegalArgumentException e) {
		    throw new MyIllegalArgumentException("Exception thrown by Line Constructor");
		}
		
		
		
	} // End of PSVM


	private double theArea = 0.0;
	private double thePerimeter = 0.0;
	private double theBoundary = 0.0;
	private double theLineLength = 0.0;
	
	// Min and Max coordinates of the line end points for bounding rectangle calc
	
	double inf = Double.POSITIVE_INFINITY;
	double nInf = Double.NEGATIVE_INFINITY;
	private double theMinX = inf;
	private double theMinY = inf;
	private double theMaxX = nInf;
	private double theMaxY = nInf;
	
	//Default Constructor
	
	public Line(){
	};
	
	// Constructor for a Line

	public Line(ArrayList<Point> points){

		 double x = 0.0; // x coordinate
		 double y = 0.0; // y coordinate
		 double line = 0.0; // line length
		 int pointCount = 0; // Point Creation Counter
		 Point p1 = new Point(x,y); // start point of a line
		 Point p2 = new Point(x,y); // end point of a line
		 
		 // Fields to compute bounding rectangle
		 
		
		 Point pmax = new Point(x,y); //max xy of bounding rectangle (if exists)
		 Point pmin = new Point(x,y); //min xy of bounding rectangle (if exists)
		 double maxX = nInf;
		 double maxY = nInf;
		 double minX = inf;
		 double minY = inf;
		 double base = 0.0; // base of bounding rectangle
		 double height = 0.0; // height of bounding rectangle
		 
		/* Compute length of line segment */
	
		for(int i = 0; i <= points.size()-2; i++){ // -1 for index, and -1 for # of segments (# points - 1) 
			
			try {
				
				theLineLength += calcSegLen(points.get(i), points.get(i+1));
				
			} catch (IllegalArgumentException e) {
			    throw new MyIllegalArgumentException("Exception thrown by calcseglen in line Constructor");
			}
		}
		
		// Determine min and max points from the set of points entered 
		// to calculate diagonal of bounding rectangle
		

		for(int i = 0; i <= points.size()-1; i++)
		{

			theMinX = Math.min(points.get(i).getxCoord(), theMinX);
			theMinY = Math.min(points.get(i).getyCoord(), theMinY);
			theMaxX = Math.max(points.get(i).getxCoord(), theMaxX);
			theMaxY = Math.max(points.get(i).getyCoord(), theMaxY);
			
		}

		// If the line is a straight line, no bounding rectangle
	
		if(minX == maxX && minY == maxY) { // This is a straight line, you're done
				theBoundary = 0.0;
		} else {	
				// Calculate Base and Height of Bounding Rectangle
			
				Point b1 = new Point(theMinX, theMinY);
				Point b2 = new Point(theMaxX, theMaxY);	
				base = calcSegLen(b1, b2);
				Point h1 = new Point(theMaxX, theMinY);
				Point h2 = new Point(theMaxX, theMaxY);
				height = calcSegLen(b1, b2);
				theBoundary = 2 * base * height;
				
		}
	
} // End of Constructor	

	
// Getters

	@Override
	public double getArea() {
		return 0;	 // A line has no area
	}

	@Override
	public double getPerimeter() {
		return 2 * (this.theLineLength);
	}

	@Override
	public double getMinimumBoundingRectangle() {
		return this.theBoundary;
	}

	@Override
	public void move(double x, double y) {
		
		theMinX += x;
		theMinY += y;
			
	}	
	
}
