package cp120a.hummem.hw6;

import java.util.Scanner;
import java.util.ArrayList;
import java.math.*;

public abstract class Shape implements Movable, Named {

	private double area = 0.0;
	private double perimeter = 0.0;
	private double boundary = 0.0;
	String name = null;
	
	// default constructor
	
	public Shape(){	
	}
	
	// Abstract method declarations
	
	public abstract double getArea();
	public abstract double getPerimeter();
	public abstract double getMinimumBoundingRectangle();
	public abstract void move(double x, double y);
	
	
	// Get a pair of X and Y coordinates
	
	public static void getCoords(ArrayList<Double> arr, String instruction, String desc1, String desc2) throws MyIllegalArgumentException{
		 
		int arrSize = 0;
		double x = 0.0;
		
		 Scanner input = new Scanner(System.in);
		 	
		 	System.out.println("\n"+ instruction + "\n");
		 	
	        System.out.print(desc1);
	        arr.add(input.nextDouble());
	        
	        // if method called from a while loop, check loop exit condition
	        
	        arrSize = arr.size();
	        x = arr.get(arrSize - 1);
	         
	        if(x != 999.0){
		        System.out.print(desc2);
	 	        arr.add(input.nextDouble());
	        }   
		 } 
	        
	
	// Get the length of a radius or square side
	
		public static double getLen(String instruction) throws MyIllegalArgumentException{
			 
			double len = 0.0;
			
			 Scanner input = new Scanner(System.in);
			 	
			 	System.out.println("\n" + instruction);
			 	
		        len = input.nextDouble(); 
		        
		        return len;
		}
	
		// Method to return the length of a line (triangle, rectangle side, line length, etc.)
		
		public double calcSegLen(Point p1, Point p2)throws IllegalArgumentException{
			
			double xLen = 0.0;
			double yLen = 0.0;
			double segLen = 0.0;
			
			xLen = Math.pow((p2.getxCoord() - p1.getxCoord()),2);
			yLen = Math.pow((p2.getyCoord() - p1.getyCoord()),2);	
			
			// Round to 2 places

			segLen = Math.sqrt(xLen + yLen);
			segLen = Math.round(segLen * 100);
			segLen = segLen / 100; 
			
			return segLen;
		}
		
		public String getName() {
			return this.name ;
		}
		
		public void setName(String x) {
			this.name = x;
		}
			
		
		
		
		

}
