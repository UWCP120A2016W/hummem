Ivan,

Everything is working from homework 5 (sorry about the folder name) except for the sorts defined on ShapeTest. Note
the following changes:

 - I redid all of the constructor arguments (except for Line of course) to accept point parameters as specified in the
requirements for homework 3, instead of an array of x and y coordinates. Line now accepts an arrayList of points.
 - I ran (and tested) ShapeTest. The shapes are created correctly but I get an error in the lambda expressions 
about returning a double instead of an integer. I tried various casts to no effect. I have some questions for you
about the sorts.

I will have the collections examples to you as soon as possible. 

Mark