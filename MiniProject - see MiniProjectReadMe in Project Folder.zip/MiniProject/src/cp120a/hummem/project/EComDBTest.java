package cp120a.hummem.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class EComDBTest {

	public static Address jackAddress = new Address("123", "12", "WA", "Bellevue", "98004");
	public static Address jillAddress = new Address("456", "11", "WA", "Bellevue", "98006");	
	public static final Customer jack = new Customer("Jack","Thomas","jack.thomas@gmail.com",jackAddress,jackAddress);
	public static final Customer jill = new Customer("Jill","Smith","jill.smith@gmail.com",jillAddress,jillAddress);
	public static final Product iphone7 = new  Product ("123456", "iphone 7", "iphone 7 for 2016", 700, 10);
	public static final Product iphone7plus = new  Product ("112233", "iphone 7 plus", "iphone 7 plus for 2016", 800, 11);
	public static final Product samsungS7 = new  Product ("223344", "Samsung S7", "Samsung S7 for 2016", 750, 12);
	public static final Product samsungS7edge = new  Product ("556677", "Samsung S7 Edge", "Samsung S7 Edge for 2016", 850, 13);
	public static final Product paperClip = new  Product ("923722", "Paper clip", "Cheap paper clip", 2, 1000);
	public static double EPSILON = 0.0001;


	private static EComDB edb;
	
	public static EComDB getMockDB() {
		if (edb == null) {
			edb = new EComDB();
			edb.addCustomer(jack);
			edb.addProduct(iphone7);
			edb.addProduct(iphone7plus);
			edb.addProduct(samsungS7);
			edb.addProduct(samsungS7edge);
			edb.addProduct(paperClip);
		}
		return edb;
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		getMockDB();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSearchById() {
		Customer expectedCustomer = edb.searchById(jack.getId());
		assertEquals("Jack should be found in EComDB", jack ,expectedCustomer);
		assertEquals("Jack Email", jack.getEmail(),expectedCustomer.getEmail());		
	}

	@Test
	public void testAddCustomer() {
		Address tomAddress = new Address("999", "45", "WA", "Bellevue", "98006");
		Customer tom = new Customer("Tom","Thomas","tom.thomas@gmail.com",tomAddress,tomAddress);
		assertEquals("Tom should not exist in EComDB yet", edb.searchById(tom.getId()) ,null);
		edb.addCustomer(tom);
		assertEquals("Tom should exist in EComDB now", edb.searchById(tom.getId()) ,tom);
		edb.removeCustomer(tom.getId());
	}

	@Test
	public void testRemoveCustomer() {
		Address jennyAddress = new Address("999", "45", "WA", "Bellevue", "98006");
		Customer jenny = new Customer("Jenny","Adam","jenny.adam@gmail.com",jennyAddress,jennyAddress);
		assertEquals("Jenny should not exist in EComDB yet", edb.searchById(jenny.getId()) ,null);
		edb.addCustomer(jenny);
		assertEquals("Jenny should exist in EComDB now", edb.searchById(jenny.getId()) ,jenny);
		edb.removeCustomer(jenny.getId());
		assertEquals("Jenny should not exist in EComDB anymore", edb.searchById(jenny.getId()) ,null);
	}

	@Test
	public void testSearchBySku() {
		Product expectedProduct = edb.searchBySku(this.samsungS7.getSku());
		assertEquals("samsungS7 should be found in EComDB", samsungS7 ,expectedProduct);
		assertEquals("samsungS7 price ",samsungS7.getPrice(),expectedProduct.getPrice(),EPSILON );
	}

	@Test
	public void testAddProduct() {
		Product lgG5 = new  Product ("123645", "LG G5", "LG G5 for 2016", 350, 100);
		assertEquals("lgG5 should not exist in EComDB yet", edb.searchBySku(lgG5.getSku()) ,null);
		edb.addProduct(lgG5);
		assertEquals("lgG5 should exist in EComDB now", edb.searchBySku(lgG5.getSku()) ,lgG5);
		edb.removeProduct(lgG5.getSku());
	}

	@Test
	public void testRemoveProduct() {
		Product ipadPro = new  Product ("998371", "iPad Pro", "iPad Pro for 2016", 999, 10);
		assertEquals("iPad Pro should not exist in EComDB yet", edb.searchBySku(ipadPro.getSku()) ,null);
		edb.addProduct(ipadPro);
		assertEquals("iPadPro should exist in EComDB now", edb.searchBySku(ipadPro.getSku()) ,ipadPro);
		edb.removeProduct(ipadPro.getSku());
		assertEquals("iPadPro should not exist in EComDB anymore", edb.searchById(ipadPro.getSku()) ,null);

	}
	
	@Test
	public void testGetTaxRate() {
		assertEquals("98006 tax rate should 0.096",0.096,edb.getTaxRate("98006"),EPSILON );
		assertEquals("98005 tax rate should 0.095",0.095,edb.getTaxRate("98005"),EPSILON );
		assertEquals("98004 tax rate should 0.094",0.094,edb.getTaxRate("98004"),EPSILON );
		assertEquals("98001 tax rate should 0.100",0.100,edb.getTaxRate("98001"),EPSILON );	
	}

}
