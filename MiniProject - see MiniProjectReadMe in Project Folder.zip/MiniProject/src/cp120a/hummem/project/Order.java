package cp120a.hummem.project;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

public class Order {

	private static final Logger logger = Logger.getLogger("cp120a.hummem.project.Order");

	// Suggested Data Structure
	// sku -> quantity_to_purchase
	
	private HashMap<String,Integer> shippingCart;
	private EComDB ecomDB;
	private Customer customer;
	
	public Order(EComDB ecomDB, Customer c) {
		// assign instance variable
		this.ecomDB = ecomDB;
		this.customer = c;
		// create an empty shopping cart
		this.shippingCart = new HashMap<>();
	}
	
	public double calcualteTotal() {
		
		double total = 0.0;
		String cartSku = null;
		double prodPrice = 0.0;
		int prodQuantity = 0;
		double shippingCost = 0.0;
		double taxRate = 0.0;
		double taxAmount = 0.0;
		Product lookupProd = new Product();
		Address lookupAddress = new Address();
		String shippingAddressZip = null;

		
		Iterator<Entry<String, Integer>> it = shippingCart.entrySet().iterator();
		
		// 1. loop thru the content to find each product;
		// 2. find out the product price , time qty, add it to total
		
		while (it.hasNext()){
			
			Map.Entry<String, Integer> Entry = it.next();
			cartSku = Entry.getKey();
			lookupProd = EComDB.searchBySku(cartSku);
			prodPrice = lookupProd.getPrice();
			prodQuantity = findItemQty(cartSku); 
			total += prodPrice * prodQuantity;
			
		}
		
		// 3. find shipping cost base on total before tax
		
			shippingCost = EComDB.getShippingCost(total);
			
		// 4. find the tax base on customer zip ocde (MRH I used billing address).
			
			// Get customer billing address entry from address
			
			lookupAddress = customer.getShippingAddress();
			
			// Get the zip code for the billing address
			
			shippingAddressZip = lookupAddress.getZip();
			
			// Lookup the tax rate for the zip 
			
			taxRate = EComDB.getTaxRate(shippingAddressZip);
			
			// Calculate the tax amount
			
			taxAmount = (taxRate * total);
			
			// total = total (before tax) + tax + shippingCost
			
			total = total + shippingCost + taxAmount;
			
			// return grand total
			
			return total;
		
	} // end of calcualteTotal

	
	// This is a helper function I think it will be useful for
	// addToShoppingCart
	// updateShoppingCart
	private void validateSkuAndQty(String sku, int quantity) {
		// Make sure sku is valid and quantity is at lease 1
		if (sku == null || ecomDB.searchBySku(sku) == null) {
			String message = "Sku " + sku + " not found";
			logger.info(message );
			throw new IllegalArgumentException(message);
		}
		if (quantity < 0) {
			String message = "Quanity " + quantity + " not valid";
			logger.info(message );
			throw new IllegalArgumentException(message);			
		}
	}
	
	public void addToShoppingCart(String sku, int quantity) {
		
		// validate sku is not null and quantity is at least 1, otherwise throw  IllegalArgumentException
		
		validateSkuAndQty(sku, quantity);
		
		// add sku and quantity to shippingCart
		
		shippingCart.put(sku, quantity);
		
	}// end of addToShoppingCart
	
	public void updateShoppingCart(String sku, int quantity) {
		
		// validate sku is not null and quantity is at least 1, otherwise throw  IllegalArgumentException
		
		validateSkuAndQty(sku, quantity);
		
		// add sku and quantity to shippingCart
		
		shippingCart.put(sku, quantity);

	} // end of updateshoppingCart
	
	public void removeFromShoppingCart(String sku) {
		
			shippingCart.remove(sku);
		}
	
	public int findItemQty(String sku) {
		Integer qty = shippingCart.get(sku);
		if (qty == null) {
			return 0;
		} else {
			return qty.intValue();
		}
	}

}
