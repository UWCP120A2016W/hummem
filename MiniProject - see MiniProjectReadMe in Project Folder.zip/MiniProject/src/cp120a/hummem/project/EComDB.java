package cp120a.hummem.project;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

public class EComDB {

	private static final Logger logger = Logger.getLogger("cp120a.hummem.project.EComDB");

	// Suggested Data Structure
	// id->customer
	private HashMap<String,Customer> customersById;
	// email->customer
	private static HashMap<String,Customer> customersByEmail;
	// sku->product
	private static HashMap<String,Product> productBySku;
	// zip->tax
	private static HashMap<String,Double> taxByZip;

	private static final double FREE_SHIPPING_THRESHOLD = 35;
	private static final double FLAT_SHIPPING_CHARGE = 10;
	private static final double DEFAULT_TAX_RATE = 0.1;
	
	public EComDB() {
		// call HashMap constructor to populate the instance variable.
		customersById = new HashMap<>();
		customersByEmail = new HashMap<>();
		productBySku = new HashMap<>();
		// populate sales tax
		taxByZip = new HashMap<>();
		taxByZip.put("98006", Double.valueOf(0.096));
		taxByZip.put("98005", Double.valueOf(0.095));
		taxByZip.put("98004", Double.valueOf(0.094));		
	}
	public Customer searchById(String id) throws IllegalArgumentException {
		// If id is null 
		//   log message
		//   throw IllegalArgumentException
		// look up customer by using id on customersById
		
		if(id == null){
			String message = "Customer ID: " + id + " not found";
			logger.info(message );
			throw new IllegalArgumentException("searchById parameter customer.id is null");
		} 
		
		Iterator<Map.Entry<String,Customer >> it = customersById.entrySet().iterator();
		
		String foundId = null;
		Customer foundCustomer = new Customer();
		
		while (it.hasNext()){
			
			Entry<String, Customer> Entry = it.next();
			foundId = Entry.getKey();
			
			if(foundId != null) {
				foundCustomer = Entry.getValue();
				break;
			}
		} 
		return foundCustomer;
		
	} // End of searchById
	
	public void addCustomer(Customer customer) throws IllegalArgumentException {
		
		// If pass in customer is null or email is null 
		//   throw IllegalArgumentException
		// If there is already a customer (lookup from customersByEmail) with the same email address
		//   throw IllegalArgumentException

		// this is a unique new customer 
        // add to customersById  using id as key , customer as value
		// add to customersByEmail using email as key, custotmer as value
		
		if(customer == null){
			 throw new IllegalArgumentException("addCustomer Customer is null");
		} 
		
		// Lookup for same email and only put customer in ByEmail and ById
		// if email doesn't already exist
		
		String foundEmail = null;
		String foundId = null;
		
		Iterator<Map.Entry<String,Customer >> it = customersByEmail.entrySet().iterator();
		
		while (it.hasNext()){
			
			Entry<String, Customer> Entry = it.next();
			foundId = Entry.getKey();
			
			if(foundEmail == null) { // OK to add customer
				customersByEmail.put(customer.getEmail(), customer);
				customersById.put(customer.getId(), customer);
			} else {
				throw new IllegalArgumentException("addCustomer customer.email already exists");		
			}
		}
	} // End of addCustomer
	
	
	public void removeCustomer(String id) {
		
		// remove customer on customersById 
		// remove method on HashMap return the removed object.
		// remove customer on customersByEmail
		
		String foundId = null;
		String custEmail = null;
		Customer foundCustomer = new Customer();
		
		Iterator<Map.Entry<String,Customer >> it = customersById.entrySet().iterator();
		
		// Remove customer from customersbyID
		
		while (it.hasNext()){
			
			Entry<String, Customer> Entry = it.next();
			foundId = Entry.getKey();
			
			if(foundId.equals(id)) {
				foundCustomer = (Customer) Entry.getValue();
				custEmail = foundCustomer.getEmail();
				customersById.remove(foundId);
				customersByEmail.remove(custEmail);
			}
		}
		
	} // end of RemoveCustomer

	
	public static Product searchBySku(String sku) {
		
		// given the sku, look up the product from productBySku
		
		String skuKey = null;
		Product foundProduct = new Product();
		
		Iterator<Map.Entry<String,Product >> it = productBySku.entrySet().iterator();
		
		while (it.hasNext()){
			
			Map.Entry<String, Product> Entry = it.next();
			skuKey = Entry.getKey();
			
			if(skuKey.equals(sku)){
				break;
			}	
		}
				
		if(skuKey == null){
			return null;
		}else {
			return foundProduct;
		}
		
	} // end of searchBySku

	
	public void addProduct(Product product) throws IllegalArgumentException {
		
		// if product is null or the sku is null
		//  throw IllegalArgumentException
		// add product to productBySku
		
		String foundSku = null;
		String paramSku = "Not Found";
		
		if(product == null) {
			throw new IllegalArgumentException("addProduct product parameter is null");
		} 

		paramSku = product.getSku();
		
		Iterator<Map.Entry<String,Product >> it = productBySku.entrySet().iterator();	
		
		while (it.hasNext()){
			
			Entry<String, Product> Entry = it.next();
			foundSku = Entry.getKey();
			
			if(foundSku.equals(paramSku)) {
				break;
			}
		}
		
		if(foundSku.equals(paramSku))
			throw new IllegalArgumentException("addProduct sku already exists");
		else
			productBySku.put(paramSku, product);
		
	} // end of addProduct
	
	
	public void removeProduct(String sku) {

		String foundSku = null;
		
		Iterator<Map.Entry<String,Product >> it = productBySku.entrySet().iterator();
		
		while (it.hasNext()){
			
			Entry<String, Product> Entry = it.next();
			foundSku = Entry.getKey();
			if(foundSku.equals(sku)) {
				productBySku.remove(foundSku);
				break;
			}
		}
		
	} // End of RemoveProduct
	
	public static double getTaxRate(String zip) {
		
		// use zip to lookup tax from taxByZip
		// if nothing is retrun from taxByZip use DEFAULT_TAX_RATE
		
		String retZip = null;
		Double taxRate = 0.0;
		
		Iterator<Map.Entry<String,Double >> it = taxByZip.entrySet().iterator();
		
		while (it.hasNext()){
			
			Map.Entry<String, Double> Entry = it.next();
			retZip = Entry.getKey();
			
			if(retZip.equals(zip)){
				taxRate = Entry.getValue();
				break; 
			}
		}
		
		if(retZip == null)
			return DEFAULT_TAX_RATE;
		else
			return taxRate;
	
	}// End of getTaxRate
	
	public static double getShippingCost(double total) {
		
		if (total > FREE_SHIPPING_THRESHOLD)
			return 0;
		else
			return FLAT_SHIPPING_CHARGE;
	
	} // end of getDhippingCost

	
} // end of class
