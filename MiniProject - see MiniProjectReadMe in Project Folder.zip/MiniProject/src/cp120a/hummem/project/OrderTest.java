package cp120a.hummem.project;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class OrderTest {

	@Test
	public void testCalcualteTotalForStandardShipping() {
		// jill buy just paper clip , testing for standard shipping
		Order jillOrder = new Order(EComDBTest.getMockDB(), EComDBTest.jill);
		jillOrder.addToShoppingCart(EComDBTest.paperClip.getSku(), 1);
		double jillTaxRate = EComDBTest.getMockDB().getTaxRate(EComDBTest.jill.getShippingAddress().getZip());
		assertEquals("Jill zip code is 98006 , the tax rate should 0.096",0.096,jillTaxRate,EComDBTest.EPSILON );
		double jillShippingCharge = 10; // because total is less than 35
		double jillExpectedTotal = (EComDBTest.paperClip.getPrice()) * (1.0+jillTaxRate) + jillShippingCharge;
		assertEquals("Jill total ",jillExpectedTotal,jillOrder.calcualteTotal(),EComDBTest.EPSILON );
	}
	
	@Test
	public void testCalcualteTotalForFreeShipping() {	
		// jack is buy 1 x iphone7 , 2 x iphone7plus
		Order jackOrder = new Order(EComDBTest.getMockDB(), EComDBTest.jack);
		jackOrder.addToShoppingCart(EComDBTest.iphone7.getSku(), 1);
		jackOrder.addToShoppingCart(EComDBTest.iphone7plus.getSku(), 2);
		double jackTaxRate = EComDBTest.getMockDB().getTaxRate(EComDBTest.jack.getShippingAddress().getZip());
		assertEquals("Jack zip code is 98004 , the tax rate should 0.094",0.094,jackTaxRate,EComDBTest.EPSILON );
		double jackExpectedTotal = (EComDBTest.iphone7.getPrice()+ EComDBTest.iphone7plus.getPrice() * 2) * (1.0+jackTaxRate) ;
		assertEquals("Jack total ",jackExpectedTotal,jackOrder.calcualteTotal(),EComDBTest.EPSILON );
		
	}

	@Test
	public void testAddToShoppingCart() {
		Order sc = new Order(EComDBTest.getMockDB(), EComDBTest.jack);
		sc.addToShoppingCart(EComDBTest.iphone7.getSku(), 2);
		assertEquals("Testing add 2 iphone7 to shopping cart",2,sc.findItemQty(EComDBTest.iphone7.getSku()),EComDBTest.EPSILON );
		sc.removeFromShoppingCart(EComDBTest.iphone7.getSku());		
	}

	@Test
	public void testUpdateShoppingCart() {
		Order sc = new Order(EComDBTest.getMockDB(), EComDBTest.jack);
		sc.addToShoppingCart(EComDBTest.iphone7.getSku(), 2);
		assertEquals("Testing add 2 iphone7 to shopping cart",2,sc.findItemQty(EComDBTest.iphone7.getSku()),EComDBTest.EPSILON );
		sc.updateShoppingCart(EComDBTest.iphone7.getSku(), 20);
		assertEquals("Testing update qty 20 iphone7 in shopping cart",20,sc.findItemQty(EComDBTest.iphone7.getSku()),EComDBTest.EPSILON );
		sc.removeFromShoppingCart(EComDBTest.iphone7.getSku());		
	}

	@Test
	public void testRemoveFromShopping() {
		Order sc = new Order(EComDBTest.getMockDB(), EComDBTest.jack);
		sc.addToShoppingCart(EComDBTest.iphone7.getSku(), 1);
		assertEquals("Testing add 2 iphone7 to shopping cart",1,sc.findItemQty(EComDBTest.iphone7.getSku()),EComDBTest.EPSILON );
		sc.removeFromShoppingCart(EComDBTest.iphone7.getSku());		
		assertEquals("Testing no iphone7 in shopping cart",0,sc.findItemQty(EComDBTest.iphone7.getSku()),EComDBTest.EPSILON );
	}

}
