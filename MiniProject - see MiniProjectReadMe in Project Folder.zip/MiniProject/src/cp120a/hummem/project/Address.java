
package cp120a.hummem.project;

public class Address {
	private String streeNo;
	private String streeName;
	private String st;
	private String city;
	private String zip;
	
	public Address(String streeNo, String streetName, String state, String city, String zip) {
		
	}

	public Address() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((st == null) ? 0 : st.hashCode());
		result = prime * result + ((streeName == null) ? 0 : streeName.hashCode());
		result = prime * result + ((streeNo == null) ? 0 : streeNo.hashCode());
		result = prime * result + ((zip == null) ? 0 : zip.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (st == null) {
			if (other.st != null)
				return false;
		} else if (!st.equals(other.st))
			return false;
		if (streeName == null) {
			if (other.streeName != null)
				return false;
		} else if (!streeName.equals(other.streeName))
			return false;
		if (streeNo == null) {
			if (other.streeNo != null)
				return false;
		} else if (!streeNo.equals(other.streeNo))
			return false;
		if (zip == null) {
			if (other.zip != null)
				return false;
		} else if (!zip.equals(other.zip))
			return false;
		return true;
	}

	public String getStreeNo() {
		return streeNo;
	}

	public void setStreeNo(String streeNo) {
		this.streeNo = streeNo;
	}

	public String getStreeName() {
		return streeName;
	}

	public void setStreeName(String streeName) {
		this.streeName = streeName;
	}

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}
}

   

