Hi Ivan,

Well, I gave it my best shot, but as we discussed, after a certain point, I was always
about a week behind.

Project Summary:

My final stuck point is line 178 in EconDB.java:

paramSku = product.getSku();

I checked that product was not null, but paramSku always came up null. I even tried
accessing it using the object (i.e. paramSku = product.sku) and changing the scope to
package, and even that didn't work (I changed it back since of course it creates a security issue). 
I would appreciate feedback regarding that.

Regardless, I learned a lot and believe if I took this course individually, and not along
with two others, I think I would have done just fine. Also, I truly believe this course needs
a TA. If you are already a java programmer, you probably did ok. If not, for most, it was
probably a struggle.

Thanks,

Mark