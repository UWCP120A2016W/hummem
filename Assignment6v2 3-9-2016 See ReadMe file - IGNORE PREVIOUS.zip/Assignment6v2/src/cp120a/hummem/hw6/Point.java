package cp120a.hummem.hw6;

import java.util.ArrayList;
import java.util.Scanner;

import java.math.*;

public class Point extends Shape{

	
	public static void main(String[] args) {
		
		// Create new ArrayList.
		
		ArrayList<Double> coords = new ArrayList<>();
		
		// Coordinates in the constructor are double per instructions
		
		String instruction = "Enter the x and y coordinates of the point";
		getCoords(coords, instruction, "Enter x coordinate: ", "Enter y coordinate: "); 
		
		Point p  = new Point(coords.get(0), coords.get(1));
		
		// Point has no area, perimeter, or boundary
		
		System.out.println("\n\nThe point coordinates are: " + coords.get(0) + "," + coords.get(1));
		System.out.println("\nThe area of the point is: " + p.getArea()); 
		System.out.println("The perimeter of the point is: " + p.getPerimeter());
		System.out.println("The boundary of the point is: " + p.getMinimumBoundingRectangle());
	
	} // End of PSVM
	
	private double xCoord;
	private double yCoord;
	
	// Constructor for a coordinate
	
	public Point(double x, double y)
	{
		xCoord = x;
		yCoord = y;
	}
	
	@Override
	public double getArea() { // Point has no area
		return 0.0;
	}

	@Override
	public double getPerimeter() { // Point has no perimeter
		return 0.0;
	}

	@Override
	public double getMinimumBoundingRectangle() { // Point has no boundary
		return 0.0;
	}

	@Override
	public double calcSegLen(Point p1, Point p2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void move(double deltaX, double deltaY) {
		// TODO Auto-generated method stub
		
	}

	public double getxCoord() {
		return this.xCoord;
	}
	

	public double getyCoord() {
		return this.yCoord;
	}

	public void setxCoord(double x) {
		this.xCoord = x;
	}

	public void setyCoord(double y) {
		this.yCoord = y;
	}
	

} // End of Class
